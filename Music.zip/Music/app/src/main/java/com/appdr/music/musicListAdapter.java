package com.appdr.music;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class musicListAdapter extends RecyclerView.Adapter<musicListAdapter.viewHolder> {

    ArrayList<audioModel> songsList;
    Context mContext;

    public musicListAdapter(ArrayList<audioModel> songsList, Context mContext) {
        this.songsList = songsList;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.recycler_items, parent, false);
        return new musicListAdapter.viewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, @SuppressLint("RecyclerView") int position) {

        audioModel songData = songsList.get(position);
        holder.titletextview.setText(songData.getTitle());

        if (MyMediaPlayer.currentIndex==position){
            holder.titletextview.setTextColor(Color.parseColor("#FF0000"));
        }
        else {
            holder.titletextview.setTextColor(Color.parseColor("#000000"));

        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyMediaPlayer.getInstance().reset();
                MyMediaPlayer.currentIndex = position;

                Intent intent = new Intent(mContext, MusicPlayerActivity.class);
                intent.putExtra("LIST", songsList);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                mContext.startActivity(intent);

            }
        });


    }

    @Override
    public int getItemCount() {
        return songsList.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder {

        TextView titletextview;
        ImageView iconimageview;

        public viewHolder(View itemView) {
            super(itemView);
            titletextview = itemView.findViewById(R.id.music_title_text);
            iconimageview = itemView.findViewById(R.id.icon_view);
        }
    }

}
