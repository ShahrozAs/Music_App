package com.appdr.music;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;

import com.appdr.music.databinding.ActivityMusicPlayerBinding;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class MusicPlayerActivity extends AppCompatActivity {

    ActivityMusicPlayerBinding binding;
    ArrayList<audioModel> songsList;
    audioModel currentSong;

    MediaPlayer mediaPlayer=MyMediaPlayer.getInstance();
    ImageView pausePlay,next,previous;
    int x=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityMusicPlayerBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        pausePlay=findViewById(R.id.pause_play);
        next=findViewById(R.id.next);
        previous=findViewById(R.id.previous);

        binding.songTitle.setSelected(true);

        songsList=(ArrayList<audioModel>) getIntent().getSerializableExtra("LIST");
        setResourceWithMusic();

        MusicPlayerActivity.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (binding.seekBar!=null){
                    binding.seekBar.setProgress(mediaPlayer.getCurrentPosition());
                    binding.currentTime.setText(convertToMMSS(mediaPlayer.getCurrentPosition()+""));

                    if (mediaPlayer.isPlaying()){
                        pausePlay.setImageResource(R.drawable.ic_baseline_pause_circle_outline_24);
                        binding.musicIconBig.setRotation(x++);
                    }
                    else {
                        pausePlay.setImageResource(R.drawable.ic_baseline_play_circle_outline_24);
                        binding.musicIconBig.setRotation(x);

                    }

                }
                new Handler().postDelayed(this,100);
            }
        });

        binding.seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                if (mediaPlayer!=null&&b){
                    mediaPlayer.seekTo(i);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

    }

    void setResourceWithMusic(){

        currentSong=songsList.get(MyMediaPlayer.currentIndex);
        binding.songTitle.setText(currentSong.getTitle());

        binding.totalTime.setText(convertToMMSS(currentSong.getDuration()));

        pausePlay.setOnClickListener(v-> pausePlay());
        next.setOnClickListener(v-> playNextSong());
        previous.setOnClickListener(v-> playPreviousSong());

        playMusic();

    }


    private void playMusic(){

        mediaPlayer.reset();
        try {
            mediaPlayer.setDataSource(currentSong.getPath());
            mediaPlayer.prepare();
            mediaPlayer.start();
            binding.seekBar.setProgress(0);
            binding.seekBar.setMax(mediaPlayer.getDuration());
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    private void playNextSong(){
        if (MyMediaPlayer.currentIndex==songsList.size()-1){
            return;
        }

        MyMediaPlayer.currentIndex +=1;
        mediaPlayer.reset();
        setResourceWithMusic();

    }

    private void playPreviousSong(){

        if (MyMediaPlayer.currentIndex==0){
            return;
        }

        MyMediaPlayer.currentIndex -=1;
        mediaPlayer.reset();
        setResourceWithMusic();
    }

    private void pausePlay() {
        if (mediaPlayer.isPlaying()){
            mediaPlayer.pause();
        }
        else {
            mediaPlayer.start();
        }
    }


    public static String convertToMMSS(String duration){

        Long millis=Long.parseLong(duration);
        return String.format("%02d:%02d",
                TimeUnit.MILLISECONDS.toMinutes(millis)%TimeUnit.HOURS.toMinutes(1),
                TimeUnit.MILLISECONDS.toSeconds(millis)%TimeUnit.MINUTES.toSeconds(1));


    }

}